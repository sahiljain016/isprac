def encryption(key, plainText):
	msg = ''
	for x in plainText:
		if not (x.isupper()):
			msg+=chr(((((ord(x) - 97) + key)%26) + 65))
		else:
			msg = msg+x
	return msg

def decryption(key, cipherText):
	msg = ''
	for x in cipherText:
		if (x.isupper()):
			msg+=chr(((((ord(x) - 65) - key)%26)+97))
		else:
			msg = msg+x
	return msg

msg = input('Enter plain text: ')
key = int(input('Enter key: '))
cipherText = encryption(key,msg)
print('Encrypted msg: ' + cipherText)
print('Decrypted msg: '+ decryption(key, cipherText))			